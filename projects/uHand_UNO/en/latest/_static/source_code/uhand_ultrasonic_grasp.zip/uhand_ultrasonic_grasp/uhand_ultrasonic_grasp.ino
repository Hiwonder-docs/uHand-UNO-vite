#include <FastLED.h> //RGB控制库（需要导入库）
#include <Servo.h> //舵机库
#include "tone.h" //音调库
#include "Ultrasound.h" //发光超声波库

//音调定义
const static uint16_t DOC5[] = { TONE_C5 };
const static uint16_t DOC6[] = { TONE_C6 };
const static uint16_t DO_RE_MI[3] = { TONE_C5, TONE_D5, TONE_E5 };
const static uint16_t MI_RE_DO[3] = { TONE_E5, TONE_D5, TONE_C5 };
const static uint16_t MI_RE_MI_RE[4] = { TONE_C7, TONE_C6, TONE_C7, TONE_C6 };

//按键引脚
const static uint8_t keyPins[2] = { 8, 9 };
// 舵机引脚
const static uint8_t servoPins[6] = { 7, 6, 5, 4, 3, 2 };
// 蜂鸣器引脚
const static uint8_t buzzerPin = 11;
// RGB灯引脚
const static uint8_t rgbPin = 13;

// RGB灯颜色对象
static CRGB rgbs[1];

// 舵机角度相关变量 （舵机下标对应的位置： 0-大拇指 1-食指 2-中指 3-无名指 4-小指 5-云台）
static uint8_t extended_func_angles[6] = { 120, 120, 120, 120, 120, 90 }; /* 二次开发例程使用的角度数值 */
static uint8_t servo_angles[6] = { 90, 90, 90, 90, 90, 90 };  /* 舵机实际控制的角度数值 */

// 蜂鸣器相关变量
static uint16_t tune_num = 0;
static uint32_t tune_beat = 10;
static uint16_t *tune;

// 创建舵机控制对象
Servo servos[6];

// 创建超声波对象
Ultrasound ul;

// 舵机控制任务
static void servo_control(void);
// 蜂鸣器鸣响函数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len);
// 蜂鸣器任务
void tune_task(void);
// 超声波任务
void ultrasound_task(void);


void setup() {
  // 初始化串口并设置速率
  Serial.begin(9600);
  // 设置串行端口读取数据的超时时间
  Serial.setTimeout(500);
  // 初始化按键引脚
  pinMode(keyPins[0], INPUT_PULLUP);
  pinMode(keyPins[1], INPUT_PULLUP);
  // 初始化蜂鸣器引脚
  pinMode(buzzerPin, OUTPUT);
  // 绑定舵机IO口
  for (int i = 0; i < 6; ++i) {
    servos[i].attach(servoPins[i]);
  }
  // 初始化RGB控制对象
  FastLED.addLeds<WS2812, rgbPin, GRB>(rgbs, 1);
  // 初始化颜色对象
  rgbs[0] = CRGB(0, 0, 255);
  // 根据颜色发光
  FastLED.show();
  // 蜂鸣器鸣响，频率1000Hz
  tone(buzzerPin, 1000);
  // 延时
  delay(100);
  // 蜂鸣器停止
  noTone(buzzerPin);
}

void loop() {
  // 超声波任务
  ultrasound_task();
  // 蜂鸣器鸣响任务
  tune_task();
  // 舵机控制
  servo_control();
}


// 超声波任务
void ultrasound_task(void)
{
  static uint32_t last_tick = 0;
  static int posi = 100;
  static uint8_t step = 0;
  static uint8_t delay_count = 0;
  static uint8_t temp = 0;

  // 间隔100ms
  if (millis() - last_tick < 100) {
    return;
  }
  last_tick = millis();

  // 获取超声波距离
  int dis = ul.Filter();
  Serial.println(dis);

  switch(step)
  {
    case 0: //判断超声波距离
      // 大于100mm
      
      if(dis >= 100)
      {
        extended_func_angles[5] = posi;
        // 蓝色
        rgbs[0].r = 0;
        rgbs[0].g = 0;
        rgbs[0].b = 255;
        FastLED.show();
        // 发光超声波蓝色
        ul.Color(0,0,255,0,0,255);
      }else if(dis >= 0){ // 若小于100mm且大于等于0，则跳入状态2
        step++;
        // 绿色
        rgbs[0].r = 0;
        rgbs[0].g = 255;
        rgbs[0].b = 0;
        FastLED.show();
        ul.Color(0,255,0,0,255,0);
        delay_count = 0;
        // 鸣响一声
        play_tune(DOC6, 300u, 1u);
      }
      
      
      break;
    case 1:  //递小球与接小球的延时时间
      delay_count++;
      if(delay_count > 10)
      {
        step++;
        delay_count = 0;
      }
      break;
    case 2://抓取
      extended_func_angles[0] = 11;
      extended_func_angles[1] = 31;
      extended_func_angles[2] = 56;
      extended_func_angles[3] = 43;
      extended_func_angles[4] = 29;
      delay_count = 0;
      step++;
      break;
    case 3: //等待一小会儿
      delay_count++;
      if(delay_count > 5)
      {
        step++;
        temp = 1;
        delay_count = 0;
      }
      break;
    case 4:
      extended_func_angles[5] = 0;
      delay_count = 0;
      step++;
    case 5: //等待一小会儿
      delay_count++;
      if(delay_count > 7)
      {
        step++;
        temp = 1;
        delay_count = 0;
      }
      break;
    case 6: //放开
      for(int i=0;i<5;i++)
        extended_func_angles[i] = 120;
      step++;
    break;
    case 7: //等待一小会儿
      delay_count++;
      if(delay_count > 6)
      {
        step++;
        temp = 1;
        delay_count = 0;
      }
      break;
    case 8:
      extended_func_angles[5] = 100;
      delay_count = 0;
      step++;
    case 9: //等待一小会儿
      delay_count++;
      if(delay_count > 5)
      {
        step++;
        temp = 1;
        delay_count = 0;
      }
      break;
    default:
      step = 0;
      break;
  }
}

// 舵机控制任务
void servo_control(void) {
  static uint32_t last_tick = 0;
  // 间隔25毫秒
  if (millis() - last_tick < 25) {
    return;
  }
  last_tick = millis();
  // 对6个舵机分别赋值
  for (int i = 0; i < 6; ++i) {
    servo_angles[i] = servo_angles[i] * 0.85 + extended_func_angles[i] * 0.15;
    servos[i].write(i == 0 || i== 5 ? 180 - servo_angles[i] : servo_angles[i]);
  }
}

// 蜂鸣器任务
void tune_task(void) {
  static uint32_t l_tune_beat = 0;
  static uint32_t last_tick = 0;
  // 若未到定时时间 且 响的时间跟上一次的一样
  if (millis() - last_tick < l_tune_beat && tune_beat == l_tune_beat) {
    return;
  }
  l_tune_beat = tune_beat;
  last_tick = millis();
  // 若还有音调
  if (tune_num > 0) {
    tune_num -= 1;
    tone(buzzerPin, *tune++);
  } else { //无则暂停
    noTone(buzzerPin);
    tune_beat = 10;
    l_tune_beat = 10;
  }
}

// 蜂鸣器鸣响函数 参数1：音调组，参数2：音调鸣响时间，参数3：音调组元素个数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len) {
  tune = p;
  tune_beat = beat;
  tune_num = len;
}

