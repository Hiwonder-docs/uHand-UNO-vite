/***********************************/
/********uHand UNO 数手指例程********/
/****本例程适用于uHand UNO右手手掌****/
/***********************************/
#include <FastLED.h> //RGB控制库（需要导入库）
#include <Servo.h> //舵机库
#include "tone.h" //音调库

#define Touch_pin 12  //定义触摸传感器的信号端接控制板的数字口2

//音调定义
const static uint16_t DOC5[] = { TONE_C5 };
const static uint16_t DOC6[] = { TONE_C6 };
const static uint16_t DO_RE_MI[3] = { TONE_C5, TONE_D5, TONE_E5 };
const static uint16_t MI_RE_DO[3] = { TONE_E5, TONE_D5, TONE_C5 };
const static uint16_t MI_RE_MI_RE[4] = { TONE_C7, TONE_C6, TONE_C7, TONE_C6 };

//按键引脚
const static uint8_t keyPins[2] = { 8, 9 };
// 舵机引脚
const static uint8_t servoPins[6] = { 7, 6, 5, 4, 3, 2 };
// 蜂鸣器引脚
const static uint8_t buzzerPin = 11;
// RGB灯引脚
const static uint8_t rgbPin = 13;

// RGB灯颜色对象
static CRGB rgbs[1];

// 舵机角度相关变量 （舵机下标对应的位置： 0-大拇指 1-食指 2-中指 3-无名指 4-小指 5-云台）
static uint8_t extended_func_angles[6] = { 0,0,0,0,0,90 }; /* 二次开发例程使用的角度数值 */
static float servo_angles[6] = { 0,0,0,0,0,90 };  /* 舵机实际控制的角度数值 */

// 蜂鸣器相关变量
static uint16_t tune_num = 0;
static uint32_t tune_beat = 10;
static uint16_t *tune;

// 创建舵机控制对象
Servo servos[6];


// 舵机控制任务
static void servo_control(void);
// 蜂鸣器鸣响函数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len);
// 蜂鸣器任务
void tune_task(void);
// 触摸传感器任务
void touch_task(void);


void setup() {
  // 初始化串口并设置速率
  Serial.begin(9600);
  // 设置串行端口读取数据的超时时间
  Serial.setTimeout(500);
  // 初始化按键引脚
  pinMode(keyPins[0], INPUT_PULLUP);
  pinMode(keyPins[1], INPUT_PULLUP);
  // 初始化蜂鸣器引脚
  pinMode(buzzerPin, OUTPUT);
  // 绑定舵机IO口
  for (int i = 0; i < 6; ++i) {
    servos[i].attach(servoPins[i],500,2500);
  }
  // 初始化RGB控制对象
  FastLED.addLeds<WS2812, rgbPin, GRB>(rgbs, 1);
  // 初始化颜色对象
  rgbs[0] = CRGB(0, 255, 0);
  // 根据颜色发光
  FastLED.show();
  // 蜂鸣器鸣响，频率1000Hz
  tone(buzzerPin, 1000);
  // 延时
  delay(100);
  // 蜂鸣器停止
  noTone(buzzerPin);
  pinMode(Touch_pin, INPUT);//将TOUCH配置为输入(输入状态一般是将要读取这个引脚的状态，即读取传感器的反馈值）
}

void loop() {
  // 触摸按键任务
  touch_task();
  // 蜂鸣器鸣响任务
  tune_task();
  // 舵机控制
  servo_control();
}

// 触摸按键任务
void touch_task(void)
{
  static uint32_t last_tick = 0;
  static int posi = 90;
  static uint8_t step = 0;
  static uint8_t delay_count = 0;
  static uint8_t finger = 0;
  
  // 间隔40ms
  if (millis() - last_tick < 40) {
    return;
  }
  last_tick = millis();

  //按下为 0 ，松开为 1 
  uint8_t touch_value = digitalRead(Touch_pin);

  switch(step)
  {
    case 0:  // 按下则按顺序逐一张开手指
      if(touch_value == 0) //若按下
      {
        // 若finger为5时，表示已经全部张开了，要闭合手掌
        if(finger < 5)
        {
          extended_func_angles[finger] = 180;
        }else{ //弯曲当前的手指
          for(int i = 0 ; i < 5 ; i++)
          {
            extended_func_angles[i] = 0;
          }
        }
        // 若finger大于5时，则为0，否则+1
        finger = (finger + 1) > 5 ? 0 : finger + 1;
        // 鸣响一声
        play_tune(DOC6, 100, 1);
        // RGB灯蓝色
        rgbs[0].r = 0;
        rgbs[0].g = 0;
        rgbs[0].b = 250;
        FastLED.show();
        // 跳入下一状态
        step++;
      }
      break;
    case 1: //若松开，则回到状态0
      if(touch_value == 1) //若松开
      {
        // RGB灯绿色
        rgbs[0].r = 0;
        rgbs[0].g = 250;
        rgbs[0].b = 0;
        FastLED.show();
        // 回到状态0
        step = 0;
      }
      break;
    default:
      step = 0;
      break;
  }
}

// 舵机控制任务
void servo_control(void) {
  static uint32_t last_tick = 0;
  // 间隔25毫秒
  if (millis() - last_tick < 25) {
    return;
  }
  last_tick = millis();
  // 对6个舵机分别赋值
  for (int i = 0; i < 6; ++i) {
    servo_angles[i] = servo_angles[i] * 0.85 + extended_func_angles[i] * 0.15;
    servos[i].write(i == 0 || i == 5 ? 180 - servo_angles[i] : servo_angles[i]);
  }
}

// 蜂鸣器任务
void tune_task(void) {
  static uint32_t l_tune_beat = 0;
  static uint32_t last_tick = 0;
  // 若未到定时时间 且 响的时间跟上一次的一样
  if (millis() - last_tick < l_tune_beat && tune_beat == l_tune_beat) {
    return;
  }
  l_tune_beat = tune_beat;
  last_tick = millis();
  // 若还有音调
  if (tune_num > 0) {
    tune_num -= 1;
    tone(buzzerPin, *tune++);
  } else { //无则暂停
    noTone(buzzerPin);
    tune_beat = 10;
    l_tune_beat = 10;
  }
}

// 蜂鸣器鸣响函数 参数1：音调组，参数2：音调鸣响时间，参数3：音调组元素个数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len) {
  tune = p;
  tune_beat = beat;
  tune_num = len;
}
