#include <FastLED.h> //RGB控制库（需要导入库）
#include <Servo.h> //舵机库
#include "tone.h" //音调库
#include "bluetooth.h" //蓝牙接收库

//音调定义
const static uint16_t DOC5[] = { TONE_C5 };
const static uint16_t DOC6[] = { TONE_C6 };
const static uint16_t DO_RE_MI[3] = { TONE_C5, TONE_D5, TONE_E5 };
const static uint16_t MI_RE_DO[3] = { TONE_E5, TONE_D5, TONE_C5 };
const static uint16_t MI_RE_MI_RE[4] = { TONE_C7, TONE_C6, TONE_C7, TONE_C6 };

//按键引脚
const static uint8_t keyPins[2] = { 8, 9 };
// 舵机引脚
const static uint8_t servoPins[6] = { 7, 6, 5, 4, 3, 2 };
// 蜂鸣器引脚
const static uint8_t buzzerPin = 11;
// RGB灯引脚
const static uint8_t rgbPin = 13;

// RGB灯颜色对象
static CRGB rgbs[1];

// 舵机角度相关变量 （舵机下标对应的位置： 0-大拇指 1-食指 2-中指 3-无名指 4-小指 5-云台）
static uint8_t extended_func_angles[6] = { 90, 90, 90, 90, 90, 90 }; /* 二次开发例程使用的角度数值 */
static uint8_t servo_angles[6] = { 90, 90, 90, 90, 90, 90 };  /* 舵机实际控制的角度数值 */

// 蜂鸣器相关变量
static uint16_t tune_num = 0;
static uint32_t tune_beat = 10;
static uint16_t *tune;

// 创建舵机控制对象
Servo servos[6];

// 创建蓝牙接收对象
blue_controller blue_ctl;

// 创建蓝牙接收存储变量
struct uHand_Servo uhand_servos;

// 舵机控制任务
static void servo_control(void);
// 蜂鸣器鸣响函数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len);
// 蜂鸣器任务
void tune_task(void);
// 蓝牙控制任务
void blue_task(void);

void setup() {
  // 初始化串口并设置速率
  Serial.begin(9600);
  // 设置串行端口读取数据的超时时间
  Serial.setTimeout(500);
  // 初始化按键引脚
  pinMode(keyPins[0], INPUT_PULLUP);
  pinMode(keyPins[1], INPUT_PULLUP);
  // 初始化蜂鸣器引脚
  pinMode(buzzerPin, OUTPUT);
  // 绑定舵机IO口
  for (int i = 0; i < 6; ++i) {
    servos[i].attach(servoPins[i]);
  }
  // 初始化RGB控制对象
  FastLED.addLeds<WS2812, rgbPin, RGB>(rgbs, 1);
  // 初始化颜色对象
  rgbs[0] = CRGB(0, 255, 0);
  // 根据颜色发光
  FastLED.show();
  // 蜂鸣器鸣响，频率1000Hz
  tone(buzzerPin, 1000);
  // 延时
  delay(100);
  // 蜂鸣器停止
  noTone(buzzerPin); //将TOUCH配置为输入(输入状态一般是将要读取这个引脚的状态，即读取传感器的反馈值）
  // 打印
  Serial.println("start");
}

void loop() {
  // 蓝牙接收并解析
  blue_ctl.receiveHandle();
  // 蓝牙控制任务
  blue_task();
  // 蜂鸣器鸣响任务
  tune_task();
  // 舵机控制
  servo_control();
}

// 蓝牙控制任务
void blue_task(void)
{
  // 获取蓝牙信息
  bool rt = blue_ctl.get_servos(&uhand_servos);
  // 若成功
  if(rt)
  {
    // 将接收到的舵机位置赋值给uHand的对应舵机
    for(int i = 0; i < uhand_servos.num ; i++)
    {
      // 根据ID号赋值
      // 注意：ID号是从1开始的，而舵机角度数组下标是从0开始的，赋值需要（ID-1）
      switch(uhand_servos.servos[i].ID)
      {
        case 1: //大拇指，转动角度为相反的
          extended_func_angles[uhand_servos.servos[i].ID - 1] = map(uhand_servos.servos[i].Position , 1100 , 1950 , 180 , 0);
          break;

        case 2: //食指 ~ 小拇指
        case 3:
        case 4:
        case 5:
          // 将对应的阈值范围映射到[0,180]的范围内，赋值给舵机
          extended_func_angles[uhand_servos.servos[i].ID - 1] = map(uhand_servos.servos[i].Position , 1100 , 1950 , 0, 180);
          break;

        case 6: //云台转动
          // 将对应的阈值范围映射到[0,180]的范围内，赋值给舵机
          extended_func_angles[uhand_servos.servos[i].ID - 1] = map(uhand_servos.servos[i].Position , 600 , 2400 , 0, 180);
          break;
      }
    }
  }
}


// 舵机控制任务
void servo_control(void) {
  static uint32_t last_tick = 0;
  // 间隔25毫秒
  if (millis() - last_tick < 25) {
    return;
  }
  last_tick = millis();
  // 对6个舵机分别赋值
  for (int i = 0; i < 6; ++i) {
    servo_angles[i] = servo_angles[i] * 0.85 + extended_func_angles[i] * 0.15;
    servos[i].write(i == 0 || i == 5 ? 180 - servo_angles[i] : servo_angles[i]);
  }
}

// 蜂鸣器任务
void tune_task(void) {
  static uint32_t l_tune_beat = 0;
  static uint32_t last_tick = 0;
  // 若未到定时时间 且 响的时间跟上一次的一样
  if (millis() - last_tick < l_tune_beat && tune_beat == l_tune_beat) {
    return;
  }
  l_tune_beat = tune_beat;
  last_tick = millis();
  // 若还有音调
  if (tune_num > 0) {
    tune_num -= 1;
    tone(buzzerPin, *tune++);
  } else { //无则暂停
    noTone(buzzerPin);
    tune_beat = 10;
    l_tune_beat = 10;
  }
}

// 蜂鸣器鸣响函数 参数1：音调组，参数2：音调鸣响时间，参数3：音调组元素个数
void play_tune(uint16_t *p, uint32_t beat, uint16_t len) {
  tune = p;
  tune_beat = beat;
  tune_num = len;
}

