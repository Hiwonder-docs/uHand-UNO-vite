#include "uhand_ctl.h"

uhand_ctl uh_ctl;

void setup() {
  Serial.begin(115200);
  uh_ctl.serial_begin();
}

void loop() {
  //Set servo angle
  Serial.println("set angles");
  uint8_t angles[6] = {73,10,0,57,90,180};
  //Set the angles of the PWM servo to 73/10/0/57/90180 degrees, with a range of 0-180 degrees
  uh_ctl.set_angles(angles); 
  delay(1500);

  //Set buzzer
  Serial.println("set buzzer");
  //Set the frequency of the buzzer to 532 and the running time to 1000ms
  //The range of values for both parameters is 0-65535
  uh_ctl.set_buzzer(532,1000);
  delay(1500);

  //Set RGB lights
  Serial.println("set rgb");
  uint8_t rgb[3] = {0,255,0}; 
  //Set the RGB light to green (range 0-255)
  uh_ctl.set_rgb(rgb);
  delay(1500);
  
  //Read and print the servo angle in the current state
  Serial.println("read angles");
  uint8_t read_a[6] = {0,0,0,0,0,0};
  if(uh_ctl.read_angles(read_a))
  {
    Serial.print("angles: ");
    for(int i=0;i<6;i++){
      Serial.print(read_a[i]);
      Serial.print(" ");
    }
    Serial.println("");
  }
  delay(100);
  
}
